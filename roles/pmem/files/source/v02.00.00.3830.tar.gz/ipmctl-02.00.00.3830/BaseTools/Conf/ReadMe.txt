This directory contains the template files for the next generation of the
EDK II Build infrastructure.  These files will be copied into the WORKSPACE's
Conf directory if and only if the target files do not exist.

These files may be updated frequently.

The XMLSchema directory contains the EDK II Packaging XML definitions.  The
schema may change in the future.  It differs somewhat from the early versions
of the XML Schema.