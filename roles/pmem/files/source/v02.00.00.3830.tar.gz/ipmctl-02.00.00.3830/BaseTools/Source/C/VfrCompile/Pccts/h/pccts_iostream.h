#ifndef __PCCTS_IOSTREAM_H__
#define __PCCTS_IOSTREAM_H__

#ifdef PCCTS_USE_NAMESPACE_STD
#include <iostream>
#else
#include <iostream.h>
#endif

#endif
