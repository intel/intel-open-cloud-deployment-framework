#ifndef __PCCTS_STDLIB_H__
#define __PCCTS_STDLIB_H__

#ifdef PCCTS_USE_NAMESPACE_STD
#include <cstdlib>
#else
#include <stdlib.h>
#endif

#endif
