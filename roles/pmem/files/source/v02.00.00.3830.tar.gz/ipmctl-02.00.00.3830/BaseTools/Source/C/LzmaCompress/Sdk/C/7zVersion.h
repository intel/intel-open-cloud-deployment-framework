#define MY_VER_MAJOR 4
#define MY_VER_MINOR 65
#define MY_VER_BUILD 0
#define MY_VERSION "4.65"
#define MY_DATE "2009-02-03"
#define MY_COPYRIGHT ": Igor Pavlov : Public domain"
#define MY_VERSION_COPYRIGHT_DATE MY_VERSION " " MY_COPYRIGHT " : " MY_DATE
