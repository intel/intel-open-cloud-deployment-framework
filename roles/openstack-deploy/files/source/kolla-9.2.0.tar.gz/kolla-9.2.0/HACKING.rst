Kolla Style Commandments
============================

- Step 1: Read the OpenStack Style Commandments
  https://docs.openstack.org/hacking/latest/
- Step 2: Read on


Kolla Specific Commandments
-------------------------------

- [K301] Method's default argument shouldn't be mutable.
- [K302] Use LOG.warning instead of LOG.warn.
