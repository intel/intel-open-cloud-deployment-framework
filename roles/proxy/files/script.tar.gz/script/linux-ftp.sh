#!/bin/bash
# A script to set up a linux server to use linux.ftp.intel.com.

if [ -z "$LINUX_FTP" ]; then
    # set default linux-ftp
    LINUX_FTP='linux-ftp.sh.intel.com'
fi

function centos_setup(){
    echo -n 'Setting up for Centos... '
    yum repolist -v  |grep $LINUX_FTP > /dev/null 2>&1
    ret=$?
    if [ $ret -ne 0 ]; then
       mv /etc/yum.repos.d/CentOS-Base.repo /etc/yum.repos.d/CentOS-Base.repo.$(date +%Y%m%d).bak 2>/dev/null
       mv /etc/yum.repos.d/epel.repo /etc/yum.repos.d/epel.repo.$(date +%Y%m%d).bak 2>/dev/null
       cat <<EOF > /etc/yum.repos.d/CentOS-Base.repo
[base]
baseurl = http://$LINUX_FTP/pub/mirrors/centos/\$releasever/os/\$basearch
enabled = 1
gpgcheck = 1
gpgkey = file:///etc/pki/rpm-gpg/RPM-GPG-KEY-CentOS-7
name = CentOS-\$releasever - Base

[updates]
baseurl = http://$LINUX_FTP/pub/mirrors/centos/\$releasever/updates/\$basearch/
enabled = 1
gpgcheck = 1
gpgkey = file:///etc/pki/rpm-gpg/RPM-GPG-KEY-CentOS-7
name = CentOS-\$releasever - Updates

[extras]
baseurl = http://$LINUX_FTP/pub/mirrors/centos/\$releasever/extras/\$basearch/
enabled = 1
gpgcheck = 1
gpgkey = file:///etc/pki/rpm-gpg/RPM-GPG-KEY-CentOS-7
name = CentOS-\$releasever - Extras

[centosplus]
baseurl = http://$LINUX_FTP/pub/mirrors/centos/\$releasever/centosplus/\$basearch/
enabled = 1
gpgcheck = 1
gpgkey = file:///etc/pki/rpm-gpg/RPM-GPG-KEY-CentOS-7
name = CentOS-\$releasever - Plus
EOF

    cat <<EOF > /etc/yum.repos.d/epel.repo
[epel]
baseurl = http://$LINUX_FTP/pub/mirrors/fedora/epel/7/\$basearch
enabled = 1
gpgcheck = 1
gpgkey = file:///etc/pki/rpm-gpg/RPM-GPG-KEY-EPEL-7
name = Extra Packages for Enterprise Linux 7 - \$basearch

[epel-debuginfo]
baseurl = http://$LINUX_FTP/pub/mirrors/fedora/epel/7/\$basearch/debug/
enabled = 0
gpgcheck = 1
gpgkey = file:///etc/pki/rpm-gpg/RPM-GPG-KEY-EPEL-7
name = Extra Packages for Enterprise Linux 7 - \$basearch - Debug

[epel-source]
baseurl = http://$LINUX_FTP/pub/mirrors/fedora/epel/7/SRPMS/
enabled = 0
gpgcheck = 1
gpgkey = file:///etc/pki/rpm-gpg/RPM-GPG-KEY-EPEL-7
name = Extra Packages for Enterprise Linux 7 - \$basearch - Source


EOF
        echo 'DONE'
    else
        echo 'N/A'
        echo
        echo "This system is already configured for ${LINUX_FTP}."
    fi
}

function debian_setup(){
    echo -n 'Setting up for Debian... '
    codename=$(lsb_release -cs)
    debian_like_setup "$codename ${codename}-updates ${codename}-backports" "main contrib"
}

function opensuse_setup(){
    echo -n 'Setting up for OpenSuSE... '
    zypper lr -d | grep $LINUX_FTP > /dev/null 2>&1
    ret=$?
    if [ $ret -ne 0 ]; then
        zypper ar "http://${LINUX_FTP}/pub/mirrors/opensuse/distribution/leap/${VERSION}/repo/non-oss/" non-oss >/dev/null
        zypper ar "http://${LINUX_FTP}/pub/mirrors/opensuse/distribution/leap/${VERSION}/repo/oss/" oss >/dev/null
        zypper ar "http://${LINUX_FTP}/pub/mirrors/opensuse/update/leap/${VERSION}/non-oss/" update-non-oss >/dev/null
        zypper ar "http://${LINUX_FTP}/pub/mirrors/opensuse/update/leap/${VERSION}/oss/" update-oss >/dev/null
        zypper refresh > /dev/null
        echo 'DONE'
    else
        echo 'N/A'
        echo
        echo "This system is already configured for ${LINUX_FTP}."
    fi
    
}

function ubuntu_setup(){
    echo -n 'Setting up for Ubuntu... '
    codename=$(lsb_release -cs)
    debian_like_setup "$codename ${codename}-updates ${codename}-security ${codename}-backports" "main restricted universe multiverse"
}


function debian_like_setup(){
    suites=$1
    components=$2
    codename=$(lsb_release -cs)
    apt-cache policy |grep $LINUX_FTP > /dev/null 2>&1
    ret=$?
    if [ $ret -ne 0 ]; then
        mv /etc/apt/sources.list /etc/apt/sources.list.$(date +%Y%m%d).bak
        mv /etc/apt/apt.conf /etc/apt/apt.conf.$(date +%Y%m%d).bak
        for suite in $suites; do
            for component in $components; do
                echo "deb http://${LINUX_FTP}/pub/mirrors/${ID} $suite $component" >> /etc/apt/sources.list
            done
        done
        echo "Acquire::http::Proxy::$LINUX_FTP \"DIRECT\";" >> /etc/apt/apt.conf
        echo "Acquire::https::Proxy::$LINUX_FTP \"DIRECT\";" >> /etc/apt/apt.conf
        echo "Acquire::http::Proxy \"http://proxy-chain.intel.com:911\";" >> /etc/apt/apt.conf
        echo "Acquire::https::Proxy \"https://proxy-chain.intel.com:912\";" >> /etc/apt/apt.conf
        apt-get update > /dev/null 2>&1
        echo 'DONE'
    else
        echo 'N/A'
        echo
        echo "This system is already configured for ${LINUX_FTP}."
    fi

}


if [ -f /etc/os-release ]; then
    . /etc/os-release
else
    echo "Error: Cannot determine OS release.  Exiting." >&2
    exit 1
fi

if [ $(id -u) -ne 0 ]; then 
    echo "Error: This script must be run as sudo/root.  Exiting." >&2
    exit 1
fi

# ID is sourced from /etc/os-release
# call one of the above setup functions.
${ID}_setup 2>/dev/null
ret=$?

if [ $ret -eq 127 ]; then
    echo "Error: unsupported OS.  Exiting."
    exit 1
fi

