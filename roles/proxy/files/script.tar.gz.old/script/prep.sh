#!/bin/bash
set -x
# mount the nfs directory as git_base
if [ x$DISTRO == "xUbuntu" ]; then
sudo apt install -y nfs-common git
else 
sudo yum install -y nfs-utils git
fi
if [ $LOCAL_CACHE == "/opt/git" ]; then
sudo mkdir $LOCAL_CACHE
sudo mount -t nfs $gitcache:/data/git $LOCAL_CACHE
fi
#if [ $LM_ENABLED = "True" ]
#then
#./lm-prep.sh
#fi
