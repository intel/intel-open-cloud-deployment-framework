tar cvzf script.tar.gz script
scp script.tar.gz cloud@otcloud-gateway.bj.intel.com:/var/www/html/
