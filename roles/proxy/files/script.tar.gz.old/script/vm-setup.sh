#!/bin/bash
set -x
source environment.inc

if [ x$DISTRO == "xUbuntu" ]; then
echo "Ubuntu"
./apt-source.sh
else
echo "CentOS"
sudo ./linux-ftp.sh
sudo curl http://$LINUX_FTP/pub/mirrors/fedora/epel/RPM-GPG-KEY-EPEL-7 -o /etc/pki/rpm-gpg/RPM-GPG-KEY-EPEL-7
fi

./redsocks.sh
if [ $INTEL_PROXY == "127.0.0.1" ]; then
	./tunnel.sh
fi

