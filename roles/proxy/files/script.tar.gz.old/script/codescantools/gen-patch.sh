#!/bin/bash
# set -x

DIRECT=nova-patches
i=1
while read -r commit
do
    echo "$commit to patch $i"
    git show $commit > $DIRECT/patch.$i
    let i++
done < commits
