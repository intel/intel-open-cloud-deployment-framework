#!/bin/bash
set -x
# git clone https://yongfeng@git-amr-1.devtools.intel.com/gerrit/openstackcore-cyborg fpga-provider-poc-2
# git clone https://yongfeng@git-amr-4.devtools.intel.com/gerrit/openstackcore-nova poc
# git clone https://yongfeng@git-amr-1.devtools.intel.com/gerrit/openstackcore-python-cyborgclient poc
PROJECT=${1:-https://yongfeng@git-amr-1.devtools.intel.com/gerrit/openstackcore-cyborg}
BRANCH=${2:-fpga-provider-poc-2}
DEPTH=${3:-10}
git clone $PROJECT -b $BRANCH --depth $DEPTH
