Functional tests
================

These playbooks aim to individually validate each Ceph component.
Some of them require packages to be installed.
Ideally you will run these tests from a client machine or from the Ansible server.
