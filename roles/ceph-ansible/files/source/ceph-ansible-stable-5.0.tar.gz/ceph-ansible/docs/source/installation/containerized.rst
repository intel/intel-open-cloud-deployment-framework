Containerized deployment
========================

Ceph-ansible supports docker and podman only in order to deploy Ceph in a containerized context.