# Ansible role: ceph-mgr

Documentation is available at http://docs.ceph.com/ceph-ansible/.
