# Ansible role: ceph-mon

Documentation is available at http://docs.ceph.com/ceph-ansible/.
